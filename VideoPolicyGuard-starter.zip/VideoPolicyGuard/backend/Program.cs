using Microsoft.EntityFrameworkCore;
using VideoPolicyGuard.Api.Models;
using VideoPolicyGuard.Api.Services;

var builder = WebApplication.CreateBuilder(args);

const long maxUploadBytes = 500L * 1024 * 1024;
builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = maxUploadBytes);
builder.Services.Configure<Microsoft.AspNetCore.Http.Features.FormOptions>(o =>
{
    o.MultipartBodyLengthLimit = maxUploadBytes;
});

var cs = builder.Configuration.GetConnectionString("Default")
    ?? "Server=localhost,1433;Database=VideoPolicyGuard;User Id=sa;Password=YourStrong!Passw0rd;TrustServerCertificate=True;";

builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlServer(cs));
builder.Services.AddHttpClient<AiClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["AiService:BaseUrl"] ?? "http://localhost:8000");
    client.Timeout = TimeSpan.FromMinutes(15);
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// SQL Server có thể cần vài giây để sẵn sàng khi Docker vừa khởi động.
for (var attempt = 1; attempt <= 20; attempt++)
{
    try
    {
        using var scope = app.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        await db.Database.EnsureCreatedAsync();
        break;
    }
    catch when (attempt < 20)
    {
        await Task.Delay(2000);
    }
}

app.UseSwagger();
app.UseSwaggerUI();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/health", () => Results.Ok(new { status = "ok" }));

app.MapGet("/api/videos", async (AppDbContext db) =>
{
    var data = await db.Videos.OrderByDescending(x => x.UploadedAt).Take(100).ToListAsync();
    return Results.Ok(data);
});

app.MapGet("/api/videos/{id:guid}", async (Guid id, AppDbContext db) =>
{
    var video = await db.Videos.FindAsync(id);
    if (video is null) return Results.NotFound();
    var violations = await db.Violations.Where(x => x.VideoId == id).ToListAsync();
    return Results.Ok(new { video, violations });
});

app.MapPost("/api/videos/upload", async (
    HttpRequest request,
    AppDbContext db,
    AiClient ai,
    IConfiguration config) =>
{
    if (!request.HasFormContentType)
        return Results.BadRequest(new { error = "multipart/form-data required" });

    var form = await request.ReadFormAsync();
    var file = form.Files.GetFile("video");
    var platform = form["platform"].FirstOrDefault() ?? "generic";

    if (file is null || file.Length == 0)
        return Results.BadRequest(new { error = "Chưa chọn video" });

    var allowedExt = new[] { ".mp4", ".mov", ".mkv", ".avi", ".webm" };
    var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
    if (!allowedExt.Contains(ext))
        return Results.BadRequest(new { error = "Định dạng video không hỗ trợ" });

    const long maxSize = 500L * 1024 * 1024;
    if (file.Length > maxSize)
        return Results.BadRequest(new { error = "Video vượt quá 500MB" });

    var uploadPath = config["Uploads:Path"] ?? Path.Combine(AppContext.BaseDirectory, "uploads");
    Directory.CreateDirectory(uploadPath);

    var id = Guid.NewGuid();
    var stored = $"{id}{ext}";
    var fullPath = Path.Combine(uploadPath, stored);

    await using (var stream = File.Create(fullPath))
        await file.CopyToAsync(stream);

    var row = new VideoRecord
    {
        Id = id,
        OriginalFileName = file.FileName,
        StoredFileName = stored,
        PlatformCode = platform,
        FileSizeBytes = file.Length,
        Status = "Analyzing"
    };
    db.Videos.Add(row);
    await db.SaveChangesAsync();

    try
    {
        var result = await ai.AnalyzeAsync(fullPath, platform);

        foreach (var f in result.Findings)
        {
            db.Violations.Add(new ViolationRecord
            {
                VideoId = id,
                Category = f.Category,
                RuleCode = f.RuleCode,
                Severity = f.Severity,
                Confidence = (decimal)Math.Clamp(f.Confidence, 0, 1),
                StartSecond = f.StartSecond is null ? null : (decimal)f.StartSecond.Value,
                EndSecond = f.EndSecond is null ? null : (decimal)f.EndSecond.Value,
                Evidence = f.Evidence
            });
        }

        row.Status = result.RequiresHumanReview ? "NeedsReview" : "Completed";
        await db.SaveChangesAsync();

        return Results.Ok(new
        {
            videoId = id,
            row.Status,
            result.RiskScore,
            result.RequiresHumanReview,
            result.Findings
        });
    }
    catch (Exception ex)
    {
        row.Status = "Failed";
        await db.SaveChangesAsync();
        return Results.Problem("Phân tích thất bại: " + ex.Message);
    }
});

app.Run();
