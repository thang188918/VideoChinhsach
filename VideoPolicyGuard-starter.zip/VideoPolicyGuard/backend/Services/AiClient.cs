using System.Net.Http.Json;

namespace VideoPolicyGuard.Api.Services;

public class AiClient(HttpClient http)
{
    public async Task<AiAnalysisResponse> AnalyzeAsync(string filePath, string platform)
    {
        var res = await http.PostAsJsonAsync("/analyze", new {
            file_path = filePath,
            platform = platform
        });
        res.EnsureSuccessStatusCode();
        return (await res.Content.ReadFromJsonAsync<AiAnalysisResponse>())!;
    }
}

public class AiAnalysisResponse
{
    public string Status { get; set; } = "";
    public double RiskScore { get; set; }
    public bool RequiresHumanReview { get; set; }
    public List<AiFinding> Findings { get; set; } = new();
}

public class AiFinding
{
    public string Category { get; set; } = "";
    public string? RuleCode { get; set; }
    public int Severity { get; set; }
    public double Confidence { get; set; }
    public double? StartSecond { get; set; }
    public double? EndSecond { get; set; }
    public string? Evidence { get; set; }
}
