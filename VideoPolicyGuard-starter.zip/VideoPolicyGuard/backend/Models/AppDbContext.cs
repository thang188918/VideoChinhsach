using Microsoft.EntityFrameworkCore;

namespace VideoPolicyGuard.Api.Models;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<VideoRecord> Videos => Set<VideoRecord>();
    public DbSet<ViolationRecord> Violations => Set<ViolationRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<VideoRecord>().ToTable("Videos");
        modelBuilder.Entity<ViolationRecord>().ToTable("Violations");
    }
}

public class VideoRecord
{
    public Guid Id { get; set; }
    public string OriginalFileName { get; set; } = "";
    public string StoredFileName { get; set; } = "";
    public string PlatformCode { get; set; } = "generic";
    public long FileSizeBytes { get; set; }
    public string Status { get; set; } = "Uploaded";
    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;
}

public class ViolationRecord
{
    public long Id { get; set; }
    public Guid VideoId { get; set; }
    public string Category { get; set; } = "";
    public string? RuleCode { get; set; }
    public int Severity { get; set; }
    public decimal Confidence { get; set; }
    public decimal? StartSecond { get; set; }
    public decimal? EndSecond { get; set; }
    public string? Evidence { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
