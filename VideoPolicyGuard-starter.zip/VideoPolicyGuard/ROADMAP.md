# Roadmap hoàn thiện

## Giai đoạn 1 - MVP
- Upload video
- Chọn nền tảng
- OCR + keyword policy
- Lưu kết quả SQL Server
- Giao diện kết quả
- Docker

## Giai đoạn 2 - AI thật
- Speech-to-text
- NSFW classifier
- Violence/gore classifier
- Weapon/drug detector
- Hate/harassment text classifier
- Confidence calibration

## Giai đoạn 3 - Moderation workflow
- Queue duyệt
- Reviewer role
- Approve / Reject / Escalate
- Audit trail
- SLA
- Bulk actions

## Giai đoạn 4 - Policy Ops
- Version policy
- Import official policy
- Effective date
- Rule mapping
- A/B validation
- Regression test

## Giai đoạn 5 - Production hardening
- Authentication
- RBAC
- Object storage
- Queue
- Monitoring
- Backup
- Encryption
- Data retention
- Privacy
