from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pathlib import Path
import cv2, json, re
import pytesseract

app = FastAPI(title="VideoPolicyGuard AI Service", version="1.0.0")

BASE = Path(__file__).resolve().parent
POLICY_DIR = BASE / "policies"

class AnalyzeRequest(BaseModel):
    file_path: str
    platform: str = "generic"

class Finding(BaseModel):
    category: str
    ruleCode: str | None = None
    severity: int
    confidence: float
    startSecond: float | None = None
    endSecond: float | None = None
    evidence: str | None = None

def load_policy(platform: str):
    safe = re.sub(r"[^a-z0-9_-]", "", platform.lower())
    p = POLICY_DIR / f"{safe}.json"
    if not p.exists():
        p = POLICY_DIR / "generic.json"
    return json.loads(p.read_text(encoding="utf-8"))

def sample_frames(path: str, every_seconds: float = 4.0, max_frames: int = 80):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise ValueError("Không đọc được video")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    total = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    duration = total / fps if fps else 0
    frames = []
    t = 0.0
    while t <= duration and len(frames) < max_frames:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, frame = cap.read()
        if not ok:
            break
        frames.append((t, frame))
        t += every_seconds
    cap.release()
    return frames, duration

def ocr_text(frame):
    try:
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        return pytesseract.image_to_string(rgb, lang="eng").strip()
    except Exception:
        return ""

def keyword_findings(text: str, time_sec: float, policy: dict):
    findings = []
    low = text.lower()
    for rule in policy.get("rules", []):
        hits = [k for k in rule.get("keywords", []) if k.lower() in low]
        if hits:
            findings.append({
                "category": rule["category"],
                "ruleCode": rule.get("rule_code"),
                "severity": int(rule.get("severity", 2)),
                "confidence": min(0.95, 0.62 + 0.06 * len(hits)),
                "startSecond": time_sec,
                "endSecond": time_sec + 2.0,
                "evidence": f"OCR keyword: {', '.join(hits[:5])}; text={text[:220]}"
            })
    return findings

def dedupe(findings):
    out = []
    seen = set()
    for f in findings:
        key = (f["category"], f.get("ruleCode"), round((f.get("startSecond") or 0)/4))
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    p = Path(req.file_path)
    if not p.exists():
        raise HTTPException(404, "Video file not found")

    policy = load_policy(req.platform)

    try:
        frames, duration = sample_frames(str(p))
    except Exception as ex:
        raise HTTPException(400, str(ex))

    findings = []
    for t, frame in frames:
        text = ocr_text(frame)
        if text:
            findings.extend(keyword_findings(text, t, policy))

    findings = dedupe(findings)

    # Điểm rủi ro minh họa: ưu tiên severity cao + confidence cao.
    risk = 0.0
    for f in findings:
        risk = max(risk, (f["severity"] / 5.0) * f["confidence"])

    # Những nhóm nhạy cảm hoặc confidence trung bình nên chuyển người kiểm duyệt.
    sensitive = {"sexual_content","violence","self_harm"}
    requires_review = any(
        f["category"] in sensitive or 0.45 <= f["confidence"] < 0.80
        for f in findings
    )

    return {
        "status":"completed",
        "riskScore": round(risk, 4),
        "requiresHumanReview": requires_review,
        "durationSeconds": round(duration, 2),
        "sampledFrames": len(frames),
        "findings": findings,
        "notes":[
            "Bản MVP hiện phân tích OCR/rule engine.",
            "Để kiểm tra nội dung hình ảnh/âm thanh thực sự, cần gắn model chuyên dụng.",
            "Không nên coi kết quả tự động là quyết định chính sách cuối cùng."
        ]
    }
