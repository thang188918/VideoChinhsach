# VideoPolicyGuard

Hệ thống web kiểm tra video có nguy cơ vi phạm chính sách nền tảng.

## Kiến trúc
- `backend/`: ASP.NET Core 8 Web API + giao diện upload đơn giản.
- `ai-service/`: FastAPI phân tích video (OCR/text/rule engine; có điểm mở rộng để gắn model hình ảnh/âm thanh).
- `database/`: SQL Server schema.
- `docker-compose.yml`: chạy SQL Server + AI service + backend.

## Luồng xử lý
1. Người dùng chọn nền tảng và tải video.
2. Backend lưu video + tạo bản ghi phân tích.
3. Backend gọi AI service.
4. AI service:
   - lấy mẫu frame bằng OpenCV,
   - OCR nếu có Tesseract,
   - kiểm tra từ khóa/rule,
   - trả về các phát hiện có `category`, `severity`, `confidence`, `evidence`.
5. Backend lưu violation vào SQL Server.
6. UI hiển thị kết quả và trạng thái cần review.

## Chạy nhanh bằng Docker
```bash
docker compose up --build
```

Mở:
- Web/API: http://localhost:8080
- AI service docs: http://localhost:8000/docs
- SQL Server: localhost:1433

## CSDL khi chạy lần đầu
Backend tự tạo database/tables tối thiểu cần để MVP chạy (`Videos`, `Violations`).
File `database/init.sql` chứa schema mở rộng cho policy version, review workflow và audit; có thể chạy thêm trong SSMS khi phát triển các module quản trị.

## Tài khoản SQL Server
- User: `sa`
- Password mặc định: `YourStrong!Passw0rd`
- Hãy đổi password qua biến môi trường khi triển khai thật.

## Lưu ý quan trọng
Các file policy mẫu trong `ai-service/policies/` chỉ là khung kỹ thuật, KHÔNG phải bản sao chính sách chính thức và không đảm bảo cập nhật. Chính sách nền tảng thay đổi theo thời gian, vì vậy hệ thống được thiết kế theo `platform + policy_version`.

## Muốn tăng độ chính xác
Thêm các model chuyên dụng vào `ai-service`:
- NSFW/nudity classifier
- violence/gore classifier
- weapon/drug detector
- speech-to-text
- OCR tốt hơn
- logo/copyright matching
- hate/harassment text classifier

Không nên tự động xóa/chặn video chỉ dựa vào một model. Nên dùng cơ chế Human Review khi confidence thấp hoặc category nhạy cảm.
