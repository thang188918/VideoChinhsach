# Kiến trúc đề xuất

## 1. Frontend
- Upload video
- Chọn nền tảng
- Xem tiến trình
- Xem timeline phát hiện
- Trang Human Review
- Trang quản lý policy/version
- Dashboard thống kê

## 2. Backend ASP.NET Core
Module:
- Video Management
- Analysis Orchestrator
- Policy Management
- Review Workflow
- Audit Log
- User/Role
- Report/Export

## 3. AI Service
Pipeline chuẩn:
1. Validate file
2. FFmpeg probe
3. Sample frames
4. ASR (speech-to-text)
5. OCR
6. Visual classifiers
7. Object detection
8. Text moderation
9. Policy mapping
10. Risk fusion
11. Human-review routing

## 4. CSDL
Các bảng chính:
- Platforms
- PolicyVersions
- PolicyRules
- Videos
- AnalysisJobs
- Violations
- ReviewDecisions
- AuditLogs

## 5. Production
Nên bổ sung:
- Redis + queue
- Object storage (S3/MinIO/Azure Blob)
- background workers
- antivirus scan
- JWT/OIDC
- rate limit
- structured logging
- OpenTelemetry
- secrets manager
- backup SQL Server
