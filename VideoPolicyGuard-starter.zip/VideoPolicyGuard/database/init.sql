IF DB_ID('VideoPolicyGuard') IS NULL
BEGIN
    CREATE DATABASE VideoPolicyGuard;
END
GO

USE VideoPolicyGuard;
GO

IF OBJECT_ID('dbo.Platforms','U') IS NULL
CREATE TABLE dbo.Platforms (
    Id INT IDENTITY PRIMARY KEY,
    Code NVARCHAR(50) NOT NULL UNIQUE,
    Name NVARCHAR(100) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

IF OBJECT_ID('dbo.PolicyVersions','U') IS NULL
CREATE TABLE dbo.PolicyVersions (
    Id INT IDENTITY PRIMARY KEY,
    PlatformId INT NOT NULL,
    VersionName NVARCHAR(100) NOT NULL,
    EffectiveFrom DATETIME2 NULL,
    EffectiveTo DATETIME2 NULL,
    SourceUrl NVARCHAR(1000) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_PolicyVersions_Platforms FOREIGN KEY (PlatformId) REFERENCES dbo.Platforms(Id)
);

IF OBJECT_ID('dbo.PolicyRules','U') IS NULL
CREATE TABLE dbo.PolicyRules (
    Id INT IDENTITY PRIMARY KEY,
    PolicyVersionId INT NOT NULL,
    RuleCode NVARCHAR(100) NOT NULL,
    Category NVARCHAR(100) NOT NULL,
    Title NVARCHAR(250) NOT NULL,
    Description NVARCHAR(MAX) NULL,
    Severity INT NOT NULL DEFAULT 2,
    AutoActionThreshold DECIMAL(5,4) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CONSTRAINT FK_PolicyRules_PolicyVersions FOREIGN KEY (PolicyVersionId) REFERENCES dbo.PolicyVersions(Id)
);

IF OBJECT_ID('dbo.Videos','U') IS NULL
CREATE TABLE dbo.Videos (
    Id UNIQUEIDENTIFIER PRIMARY KEY,
    OriginalFileName NVARCHAR(500) NOT NULL,
    StoredFileName NVARCHAR(500) NOT NULL,
    PlatformCode NVARCHAR(50) NOT NULL,
    FileSizeBytes BIGINT NOT NULL,
    Status NVARCHAR(50) NOT NULL,
    UploadedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

IF OBJECT_ID('dbo.AnalysisJobs','U') IS NULL
CREATE TABLE dbo.AnalysisJobs (
    Id UNIQUEIDENTIFIER PRIMARY KEY,
    VideoId UNIQUEIDENTIFIER NOT NULL,
    Status NVARCHAR(50) NOT NULL,
    StartedAt DATETIME2 NULL,
    FinishedAt DATETIME2 NULL,
    ModelVersion NVARCHAR(100) NULL,
    ErrorMessage NVARCHAR(MAX) NULL,
    CONSTRAINT FK_AnalysisJobs_Videos FOREIGN KEY (VideoId) REFERENCES dbo.Videos(Id)
);

IF OBJECT_ID('dbo.Violations','U') IS NULL
CREATE TABLE dbo.Violations (
    Id BIGINT IDENTITY PRIMARY KEY,
    VideoId UNIQUEIDENTIFIER NOT NULL,
    Category NVARCHAR(100) NOT NULL,
    RuleCode NVARCHAR(100) NULL,
    Severity INT NOT NULL,
    Confidence DECIMAL(5,4) NOT NULL,
    StartSecond DECIMAL(10,3) NULL,
    EndSecond DECIMAL(10,3) NULL,
    Evidence NVARCHAR(MAX) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Violations_Videos FOREIGN KEY (VideoId) REFERENCES dbo.Videos(Id)
);

IF OBJECT_ID('dbo.ReviewDecisions','U') IS NULL
CREATE TABLE dbo.ReviewDecisions (
    Id BIGINT IDENTITY PRIMARY KEY,
    VideoId UNIQUEIDENTIFIER NOT NULL,
    Reviewer NVARCHAR(200) NOT NULL,
    Decision NVARCHAR(50) NOT NULL,
    Notes NVARCHAR(MAX) NULL,
    ReviewedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_ReviewDecisions_Videos FOREIGN KEY (VideoId) REFERENCES dbo.Videos(Id)
);

IF OBJECT_ID('dbo.AuditLogs','U') IS NULL
CREATE TABLE dbo.AuditLogs (
    Id BIGINT IDENTITY PRIMARY KEY,
    Actor NVARCHAR(200) NULL,
    Action NVARCHAR(200) NOT NULL,
    EntityType NVARCHAR(100) NULL,
    EntityId NVARCHAR(200) NULL,
    Detail NVARCHAR(MAX) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

MERGE dbo.Platforms AS t
USING (VALUES
 ('youtube','YouTube'),
 ('tiktok','TikTok'),
 ('facebook','Facebook'),
 ('instagram','Instagram'),
 ('generic','Generic')
) AS s(Code,Name)
ON t.Code=s.Code
WHEN NOT MATCHED THEN INSERT(Code,Name) VALUES(s.Code,s.Name);
GO
